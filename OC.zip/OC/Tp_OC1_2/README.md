# Tp_OC1_2

A fazer: 
lb
sb
sub
and
ori
srl
beq


Pelo menos as primeiras 32 posições da memória devem ser exibidas na tela.
